￼year=int(input("enter the year:")) 
if(year%4000) and /year%100==0) ;
print(year, "is leap year")
elif(year%4==0))and(year%100! =0);
print(year, " is leap year")
else:
print(year, "is not leap year")